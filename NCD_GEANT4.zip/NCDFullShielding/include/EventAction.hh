#ifndef EventAction_h
#define EventAction_h 1

#include "G4UserEventAction.hh"
#include "globals.hh"

class G4Event;

class EventAction : public G4UserEventAction {
public:
    EventAction();
    virtual ~EventAction();

    virtual void BeginOfEventAction(const G4Event*);
    virtual void EndOfEventAction(const G4Event*);

private:
    G4double fEventEdep = 0.0;

public:
    void AddEdep(G4double edep);
    G4double GetEdep() const;
    G4int EventIDCounter;
};

#endif
